exports.handler = async(event) => {
    //actual body code: handles getting a response
    //from the bored API.
    const axios = require('axios');
    console.log("Getting Bored API requested item...");
    axios.get('https://www.boredapi.com/api/activity/').then(response => {
        console.log(response.data);
        return response.data;
    }).catch(error => {
        console.log(error);
        return error;
    });
}